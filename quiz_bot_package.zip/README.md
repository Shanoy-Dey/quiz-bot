# Quiz Bot for Medical Students

This bot provides quizzes from Google Sheets for NEET/Medical entrance students.

## Features
- Subjects: Physics, Zoology, Botany, Phy. Chemistry, In. Chemistry, Organic Chemistry
- Mixed Quiz option
- Choose number of questions (5,10,20,45)
- Timer: 2 minutes per question
- Auto-restart after quiz
- 24x7 hosted via Render.com

## Deployment
1. Upload code to GitHub
2. Create a Render.com account
3. Connect repository
4. Use Free Plan (Web Service)